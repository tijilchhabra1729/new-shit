var nameValidationInput = document.querySelector(".query_");
var resultsHolder = document.querySelector(".results-holder");
function useValue() {
    var NameValue = nameValidationInput.value;
    fetch(`/auto/${nameValidationInput.value}`, {
        method: "POST",
        body: "hello world",
    })
        .then((response) => response.json())
        .then((data) => {
            for (let i = 0; i < data.length; i++) {
                resultName = data[i]["sneaker_name"];
                resultPrice = data[i]["sneaker_price"];
                resultStr = resultName + "  -   " + resultPrice;
                resultsHolder.append(resultStr);
            }
        });
}
nameValidationInput.onchange = useValue;