import sqlite3

conn = sqlite3.connect('hack/dbs/main/sneaker_db.sqlite')
cur = conn.cursor()

cur.execute("SELECT * FROM 'sneaker' WHERE name LIKE '%lost%'")

for i in cur.fetchall():
    cur.execute('INSERT INTO product (name)')