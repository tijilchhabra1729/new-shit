from hack import app, create_db, db
from flask import render_template, redirect, url_for, flash, session, request, abort, jsonify, Response
import json
from flask_login import current_user, login_user, logout_user, login_required
from hack.forms import LoginForm, RegForm, SearchForm
from hack.models import User, Sneaker, Product, Source
from werkzeug.security import generate_password_hash, check_password_hash
import requests
from bs4 import BeautifulSoup as bs
from urllib.parse import unquote
import sqlite3
import re

# sk_db = sqlite3.connect('hack/dbs/crepdog.sqlite', check_same_thread=False)
# cur = sk_db.cursor()


create_db(app)

headers = {
    'User-Agent': 'Mozilla/5.0'
}

@app.route('/')
def home():
    form = SearchForm()
    # lost = Sneaker.query.filter(Sneaker.name.like('%lost & found%')).all()
    # prod = Product.query.filter_by(id=11).first()
    # for i in lost:
    #     src = Source(company = i.source, price=i.price, url=i.url, product=prod.id)
    #     if i.img != None:
    #         prod.img = i.img
    #     db.session.add(src)
    # db.session.add(prod)
    # db.session.commit()
    # s = Source.query.all()
    # db.session.delete(s[-1])
    # for i in s[-1]:
    #     db.session.delete(i)
    #     db.session.commit()
    # sneakers = Sneaker.query.all()
    # sneakers = Sneaker.query.all()
    # for i in sneakers:
    #     prod = Product.query.filter_by(name=i.name).first()
    #     src = Source(company=i.source, price=i.price, url=i.url, product=prod.id)
    #     prod.sources.append(src)
    #     db.session.add(src)
    #     db.session.commit()
    #     db.session.add(prod)
    # # ss = []
    # for i in sneakers:
    #     check = Sneaker.query.filter(Sneaker.name.like('%' + i.name + '%')).all()
    #     if len(check) > 1:
    #         new_prod = Product(name=check[0].name)
    #         for j in check:
    #             new_src = Source(company=j.source, url=j.url, product = new_prod.id, price=j.price)
    #             new_prod.sources.append(new_src)
    #             if j.img != None:
    #                 new_prod.img = j.img
    #             db.session.add(new_src)
    #         db.session.add(new_prod)
    #         db.session.commit()
    # p = Product.query.all()
    # s = Source.query.all()
    # for i in p:
    #     db.session.delete(i)
    # for i in s:
    #     db.session.delete(i)
    # db.session.commit()
    # prod = Product(name=lostAndFounds[2].name)
    # for i in lostAndFounds:
    #     new_src = Source(company=i.source, url=i.url, price=i.price)
    #     if i.img != None:
    #         prod.img = i.img
    #     db.session.add(new_src)
    #     db.session.delete(i)
    # db.session.add(prod)
    # db.session.commit()
    # sk = Sneaker.query.filter_by(source='Crepdog').all()
    # for i in sk:
    #     cur.execute('''INSERT INTO sneaker (name, price, url,img, source) VALUES (?, ? ,?, ?, ?)''', (i.name, i.price,i.url, i.img, i.source))
    #     sk_db.commit()
    #     print(f'Added {i.name}')
    # users = User.query.all()
    # for i in users:
    #     db.session.delete(i)
    #     db.session.commit()
    #the final page where the authorized users will end up
    # sneakers = Sneaker.query.all()
    # for i in sneakers:
    #     i.price = i.price.replace(' ', '').replace(',', '')
    #     db.session.add(i)
    #     db.session.commit()
    # sneakers = Sneaker.query.all()
    # sneakers = [*set(sneakers)]
    # db.session.add(sneakers)
    # db.session.commit()
    # shoes = []
    # sneakers = Sneaker.query.all()
    # # for i in sneakers:
    # #     if i not in shoes:
    # #         shoes.append(i)
    # # print(len(shoes))
    # sk = sneakers[:447]
    # dup_names = []
    # for i in sk:
    # #     print(len(list(dict.fromkeys(sk))))
    # unique_sneakers = []
    # sneakers = Sneaker.query.all()
    # for i in sneakers:
    #     if i.name not in unique_sneakers:
    #         unique_sneakers.append(i.name)
    #     else:
    #         sneaker = Sneaker.query.filter_by(name=i.name).first()
    #         db.session.delete(sneaker)
    #         db.session.commit()
    # sneakers = Sneaker.query.all()
    # for i in sneakers[:223]:
    #     req = requests.get(i.url, headers=headers)
    #     sk = bs(req.content, 'lxml')
    #     new_price = sk.find('span', class_='price-item price-item--regular').text.strip().replace('\n', '').replace('₹ ', '').replace(',', '')
    #     if i.price != new_price:
    #         i.price = new_price
    #         db.session.add(i)
    #         db.session.commit()
    #         print(f'updates in {i.name}')
    # for i in sneakers[223:385]:
    #     # print(i.name, i.url)
    #     try:
    #         req = requests.get(i.url, headers=headers)
    #         sk = bs(req.content, 'lxml')
    #         new_price = sk.find('span', class_='price-item price-item--regular').text.strip().replace('\n', '').replace('₹ ', '').replace(',', '')
    #         if i.price != new_price:
    #             i.price = new_price
    #             db.session.add(i)
    #             db.session.commit()
    #             print(f'updates in {i.name}')
    #     except Exception as e:
    #         print(e)
    # for i in sneakers[386:525]:
    #     try:
    #         req = requests.get(i.url, headers=headers)
    #         sk = bs(req.content, 'lxml')
    #         new_price = sk.find('span', class_='money').text.strip().replace('\n', '').replace('₹', '').replace(',', '')
    #         if i.price != new_price:
    #             i.price = new_price
    #             db.session.add(i)
    #             db.session.commit()
    #     except Exception as e:
    #         print(e)
    # for i in sneakers[525:-1]:
    #     try:
    #         req = requests.get(i.url, headers=headers)
    #         sk = bs(req.content, 'html.parser')
    #         new_price = sk.find('span', class_='product-single__price').text.strip().replace('\n', '').replace('Rs. ', '').replace(',', '')
    #         if i.price != new_price:
    #             i.price = new_price
    #             db.session.add(i)
    #             db.session.commit()
    #     except Exception as e:
    #         print(e)
    # for i in sneakers[:223]:
    #     i.source = 'Superkicks'
    #     db.session.add(i)
    #     db.session.commit()
    # for i in sneakers[223:385]:
    #     i.source = 'Dawntown'
    #     db.session.add(i)
    #     db.session.commit()
    # for i in sneakers[386:525]:
    #     i.source = 'Crepdog'
    #     db.session.add(i)
    #     db.session.commit()
    # for i in sneakers[525:-1]:
    #     i.source = 'Mainstreet'
    #     db.session.add(i)
    #     db.session.commit()
    # print('done')

    return render_template('dist/index.html', form=form)

@app.route('/products/<id>')
def product(id):
    form = SearchForm()
    product = Sneaker.query.filter_by(id=id).first()
    return render_template('product.html', form=form, product=product)

# @app.route('/search', methods=['GET', 'POST'])
# def search_main():
#     form = SearchForm()
#     return render_template('dist/search.html', form=form)

@app.route('/sendsearch', methods=['GET', 'POST'])
def send_search():
    form = SearchForm()
    return redirect(url_for('search', q=form.query.data))

# @app.route('/signinwithgoogle', methods=['GET', 'POST'])
# def sign_in_with_google():
#     # Find out what URL to hit for Google login
#     google_provider_cfg = get_google_provider_cfg()
#     authorization_endpoint = google_provider_cfg["authorization_endpoint"]

#     # Use library to construct the request for Google login and provide
#     # scopes that let you retrieve user's profile from Google
#     request_uri = client.prepare_request_uri(
#         authorization_endpoint,
#         redirect_uri=request.base_url + "/callback",
#         scope=["openid", "email", "profile"],
#     )
#     return redirect(request_uri)


# @app.route('/signinwithgoogle/callback', methods=['GET', 'POST'])
# def sign_in_with_google_callback():
#     code = request.args.get("code")
#     # Find out what URL to hit to get tokens that allow you to ask for
# # things on behalf of a user
#     google_provider_cfg = get_google_provider_cfg()
#     token_endpoint = google_provider_cfg["token_endpoint"]
#     token_url, headers, body = client.prepare_token_request(
#     token_endpoint,
#     authorization_response=request.url,
#     redirect_url=request.base_url,
#     code=code
#     )
#     token_response = requests.post(
#         token_url,
#         headers=headers,
#         data=body,
#         auth=(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET),
#     )
#     client.parse_request_body_response(json.dumps(token_response.json()))
#     userinfo_endpoint = google_provider_cfg["userinfo_endpoint"]
#     uri, headers, body = client.add_token(userinfo_endpoint)
#     userinfo_response = requests.get(uri, headers=headers, data=body)
#     if userinfo_response.json().get("email_verified"):
#         unique_id = userinfo_response.json()["sub"]
#         users_email = userinfo_response.json()["email"]
#         picture = userinfo_response.json()["picture"]
#         users_name = userinfo_response.json()["given_name"]
#         email_chk = User.query.filter_by(email=users_email).first()
#         if email_chk:
#             login_user(email_chk, remember=True)
#             return redirect(url_for('home'))
#         else:
#             new_user = User(email=users_email, username=users_name, password=generate_password_hash(str(uuid4())))
#             db.session.add(new_user)
#             db.session.commit()
#             login_user(new_user)
#             return redirect(url_for('home'))
#     else:
#         return "User email not available or not verified by Google.", 400

@app.route('/auto/<data>', methods=['GET', 'POST'])
def autocomplete(data):
    query = unquote(data)
    shoes = []
    snkrs = Sneaker.query.order_by(Sneaker.price.asc()).all()
    for i in snkrs:
            if i.name.lower().replace('&', 'and').replace(' n ', 'and').find(query.lower().replace('&', 'and').replace(' n ', ' and ')) != -1:
                if i not in shoes:
                    shoes.append(i.serialize())
                else:
                    print('err')
    return Response(json.dumps(shoes), mimetype='application/json')

@app.route('/search', methods=['GET', 'POST'])
def search():
    query = request.args.get('q')
    # shoes = []
    # query = request.args.get('q')
    # query = unquote(query)
    # form = SearchForm()
    # snkrs = Sneaker.query.order_by(Sneaker.price.asc()).all()
    # for i in snkrs:
    #     if i.name.lower().replace('&', 'and').replace(' n ', 'and').find(query.lower().replace('&', 'and').replace(' n ', ' and ')) != -1:
    #         if i not in shoes:
    #             shoes.append(i)
    #         else:
    #             print('err')
    # if len(shoes) > 0:
    #     return render_template('dist/results.html', shoes=shoes, query=query, form=form)
    # else:
    #     return render_template('dist/404.html', query=query)
    if query == None:
        form = SearchForm()
        return render_template('dist/search.html', form=form)
    else:
        shoes = []
        # query = unquote(query)
        form = SearchForm()
        snkrs = Product.query.all()
        for i in snkrs:
            if i.name.lower().replace('&', 'and').replace(' n ', 'and').find(query.lower().replace('&', 'and').replace(' n ', ' and ')) != -1:
                if i not in shoes:
                    shoes.append(i)
                else:
                    print('err')
        if len(shoes) > 0:
            # for i in range(len(shoes)):
            #     for j in range(i+1, len(shoes)):
            #         k = shoes[i]
            #         l = shoes[j]
            #         words_k = re.findall(r'\w+', k.name)
            #         words_l = re.findall(r'\w+', l.name)
            #         for a in words_k:
            #             for b in words_l:
            #                 if a.find(b) != -1 or b.find(a) != -1:
            #                     if k not in sm_shoes:
            #                         sm_shoes.append(k)
            # check_snkr = Product.query.filter_by(name=sm_shoes[0].name).first()
            # if not check_snkr:
            #     prod = Product(name=sm_shoes[0].name)
            #     for c in sm_shoes:
            #         price = Price(price=c.price, product=prod.id)
            #         source = Source(url=c.url, company=c.source, product=prod.id)
            #         prod.prices.append(price)
            #         prod.sources.append(source)
            #         if c.img != None:
            #             prod.img = c.img
            #     db.session.add(prod)
            #     db.session.commit()
            return render_template('dist/results.html', query=query, shoes=shoes)
        else:
            return render_template('dist/404.html', query=query)
    
@app.route('/product/<id>')
def see_temp(id):
    prod = Product.query.filter_by(id=id).first()
    return render_template('tmp.html', prod=prod)

@app.route('/signup', methods=['GET', 'POST'])
def reg():
    form = RegForm()
    mess=''
    if form.validate_on_submit():
        email = form.email.data
        username = form.username.data
        password = form.password.data
        email_chk = User.query.filter_by(email=email).first()
        username_chk = User.query.filter_by(username=email).first()
        if email_chk or username_chk:
            mess = 'An account already exists with this email and/or username.'
        else:  
            new_user = User(email=email, username=username, password=generate_password_hash(password))
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user)
            return redirect(url_for('home'))
    return render_template('dist/register.html', form=form, mess=mess)

@app.route('/about')
def about():
    return render_template('dist/about.html')

@app.route('/signin', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    mess=''
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data
        user = User.query.filter_by(email=email).first()
        check_username = User.query.filter_by(username=email).first()
        if user:
            if check_password_hash(user.password, password):
                login_user(user, remember=True)
                return redirect(url_for('home')) 
        elif check_username:
            if check_password_hash(check_username.password, password):
                login_user(check_username, remember=True)
                return redirect(url_for('home'))
    return render_template('dist/login.html', mess=mess, form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
